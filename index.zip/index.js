const dotenv = require('dotenv').config()
const express = require('express')
const app = express()
require('./model/config');
const user = require('./routers/user_Routers')

// app.listen(8000, (req, res)=>{
//     console.log ("server is running")
//     console.log ("balii",process.env.port)
const server = app.listen(process.env.port, (req, res) => {
    console.log(`server is running on port :${process.env.port}`)
})

